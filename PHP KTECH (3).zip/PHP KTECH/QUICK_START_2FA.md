# ⚡ Quick Start - 2FA Deployment Checklist

## 🚀 5-Minute Setup

### ✅ Step 1: Deploy to Vercel
```bash
cd "c:\Users\lenovo\Pictures\PHP KTECH"
npm install -g vercel
vercel login
vercel --prod
```
**Note your deployment URL** (e.g., `https://gigsplan.vercel.app`)

---

### ✅ Step 2: Add Environment Variables
1. Go to https://vercel.com/dashboard
2. Select your project
3. Settings → Environment Variables
4. Add:
   - `BULK_SMS_API_KEY` = your API key
   - `BULK_SMS_SENDER_ID` = your sender ID
5. Redeploy: `vercel --prod`

---

### ✅ Step 3: Update Code URLs

**File 1: script.js** (line ~5066)
```javascript
// BEFORE:
API_BASE_URL: 'https://your-project.vercel.app',

// AFTER (use YOUR actual URL):
API_BASE_URL: 'https://gigsplan.vercel.app',
```

**File 2: auth.html** (line ~848)
```javascript
// BEFORE:
API_BASE_URL: 'https://your-project.vercel.app',

// AFTER (use YOUR actual URL):
API_BASE_URL: 'https://gigsplan.vercel.app',
```

---

### ✅ Step 4: Test It!

**Enable 2FA:**
1. Login → Profile
2. Toggle 2FA ON
3. Enter phone: `+233241234567`
4. Enter SMS code
5. See "2FA Enabled" ✅

**Test Login:**
1. Logout
2. Login again
3. Enter SMS code
4. Access granted ✅

---

## 🎯 That's It!

Your 2FA system is now live!

**Need help?** See [2FA_SETUP_GUIDE.md](./2FA_SETUP_GUIDE.md) for detailed instructions.

**Want details?** See [2FA_IMPLEMENTATION_SUMMARY.md](./2FA_IMPLEMENTATION_SUMMARY.md) for technical details.
