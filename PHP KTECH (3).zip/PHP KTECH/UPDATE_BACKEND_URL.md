# 🔄 Update Backend URL - Quick Guide

## Files to Update

You need to update your Vercel backend URL in **2 main files**:

### 1. script.js (Line ~5069)

**File:** `c:\Users\lenovo\Pictures\PHP KTECH\script.js`

**Find:**
```javascript
API_BASE_URL: 'https://your-project.vercel.app',  // TODO: Update this after deployment
```

**Replace with:**
```javascript
API_BASE_URL: 'https://YOUR-ACTUAL-URL.vercel.app',
```

---

### 2. auth.html (Line ~848)

**File:** `c:\Users\lenovo\Pictures\PHP KTECH\auth.html`

**Find:**
```javascript
API_BASE_URL: 'https://your-project.vercel.app', // TODO: Update after deployment
```

**Replace with:**
```javascript
API_BASE_URL: 'https://YOUR-ACTUAL-URL.vercel.app',
```

---

## How to Find Your Vercel URL

1. Deploy your project:
   ```bash
   cd "c:\Users\lenovo\Pictures\PHP KTECH"
   vercel --prod
   ```

2. After deployment, you'll see output like:
   ```
   ✅  Production: https://gigsplan.vercel.app [copied to clipboard]
   ```

3. Copy that URL (without trailing slash)

4. Replace in both files above

---

## Quick Find & Replace (VS Code)

1. Press `Ctrl + Shift + H` (Find and Replace in Files)
2. **Find:** `https://your-project.vercel.app`
3. **Replace:** `https://YOUR-ACTUAL-URL.vercel.app`
4. Click "Replace All"

This will update all occurrences across your project!

---

## Verify Changes

After updating, check these files:
- ✅ script.js (line ~5069)
- ✅ auth.html (line ~848)

The documentation files will automatically reference your actual URL.
