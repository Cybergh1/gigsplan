# 🔒 Security Implementation Examples

Quick reference for using security features in your code.

---

## 📝 Form Validation Examples

### Login Form
```javascript
// Validate email and phone
const email = SecurityManager.validateEmail(emailInput.value);
const phone = SecurityManager.validatePhone(phoneInput.value);

if (!email) {
    showToast("Error", "Please enter a valid email address", 3000, true);
    return;
}

if (!phone) {
    showToast("Error", "Invalid phone number. Format: 0XXXXXXXXX", 3000, true);
    return;
}

// Check rate limit
const rateCheck = SecurityManager.checkRateLimit(`login_${email}`, 5, 300000);
if (!rateCheck.allowed) {
    showToast("Error", rateCheck.message, 5000, true);
    return;
}

// Proceed with login...
```

### Store Setup Form
```javascript
// Validate store name
const storeName = SecurityManager.validateName(storeNameInput.value);
if (!storeName) {
    showToast("Error", "Invalid store name (2-50 characters, letters only)", 3000, true);
    return;
}

// Validate store slug
const storeSlug = SecurityManager.validateSlug(storeSlugInput.value);
if (!storeSlug) {
    showToast("Error", "Invalid store URL (3-50 characters, lowercase, hyphens)", 3000, true);
    return;
}

// Validate contact email
const contactEmail = SecurityManager.validateEmail(emailInput.value);
if (!contactEmail) {
    showToast("Error", "Invalid email address", 3000, true);
    return;
}

// Validate contact phone
const contactPhone = SecurityManager.validatePhone(phoneInput.value);
if (!contactPhone) {
    showToast("Error", "Invalid phone number", 3000, true);
    return;
}

// Validate logo file
const logoFile = brandLogoFile.files[0];
const fileValidation = SecurityManager.validateFile(logoFile);
if (!fileValidation.valid) {
    showToast("Error", fileValidation.error, 3000, true);
    return;
}

// All validation passed, proceed...
```

### Order Form
```javascript
// Validate beneficiary number
const beneficiaryNumber = SecurityManager.validatePhone(phoneInput.value);
if (!beneficiaryNumber) {
    showToast("Error", "Invalid beneficiary phone number", 3000, true);
    return;
}

// Validate amount
const amount = SecurityManager.validateAmount(amountInput.value);
if (!amount) {
    showToast("Error", "Invalid amount (0.01 - 10,000)", 3000, true);
    return;
}

// Check rate limit
const rateCheck = SecurityManager.checkRateLimit(`order_${currentUser.uid}`, 10, 60000);
if (!rateCheck.allowed) {
    showToast("Warning", rateCheck.message, 5000, false, true);
    return;
}

// Verify session token
if (!AuthTokenManager.verifyToken(currentUser.uid)) {
    showToast("Error", "Session expired. Please login again.", 3000, true);
    await signOut(auth);
    return;
}

// Proceed with order...
```

---

## 🔐 Authentication Examples

### User Login
```javascript
onAuthStateChanged(auth, async (user) => {
    if (user) {
        currentUser = user;

        // Generate session token
        await AuthTokenManager.generateToken(user.uid);

        console.log('User authenticated, token generated');
    } else {
        // Clear token on logout
        AuthTokenManager.clearToken();
    }
});
```

### Sensitive Operations
```javascript
async function performSensitiveOperation() {
    // Verify user is authenticated
    if (!currentUser) {
        showToast("Error", "Please login first", 3000, true);
        return;
    }

    // Verify session token
    if (!AuthTokenManager.verifyToken(currentUser.uid)) {
        showToast("Error", "Session expired. Please login again.", 3000, true);
        await signOut(auth);
        return;
    }

    // Proceed with operation...
}
```

---

## 🚦 Rate Limiting Examples

### API Calls
```javascript
async function makeAPICall(endpoint, data) {
    // Check rate limit
    const rateCheck = SecurityManager.checkRateLimit(
        `api_${endpoint}_${currentUser?.uid || 'anon'}`,
        20, // 20 calls
        60000 // per minute
    );

    if (!rateCheck.allowed) {
        console.error('Rate limit exceeded:', rateCheck.message);
        showToast("Error", "Too many requests. Please slow down.", 3000, true);
        return null;
    }

    // Make API call...
    const response = await fetch(endpoint, {
        method: 'POST',
        body: JSON.stringify(data)
    });

    return response;
}
```

### Form Submissions
```javascript
function handleFormSubmit() {
    const rateCheck = SecurityManager.checkRateLimit(
        `form_submit_${formName}`,
        3, // 3 submissions
        60000 // per minute
    );

    if (!rateCheck.allowed) {
        showToast("Warning", rateCheck.message, 5000, false, true);
        return;
    }

    // Process form...
}
```

---

## 📁 File Upload Examples

### Logo Upload
```javascript
async function handleLogoUpload(fileInput) {
    const file = fileInput.files[0];

    // Validate file
    const validation = SecurityManager.validateFile(
        file,
        ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
        2 * 1024 * 1024 // 2MB
    );

    if (!validation.valid) {
        showToast("Error", validation.error, 3000, true);
        fileInput.value = '';
        return null;
    }

    // Convert to base64
    const base64 = await convertImageToBase64(file);
    return base64;
}
```

---

## 🧹 XSS Prevention Examples

### Displaying User Content
```javascript
// ❌ UNSAFE
element.innerHTML = userData.name;

// ✅ SAFE
element.textContent = userData.name;

// ✅ SAFE (if HTML needed)
element.innerHTML = SecurityManager.sanitizeHTML(userData.description);
```

### Search Results
```javascript
function displaySearchResults(results) {
    const html = results.map(result => `
        <div class="result">
            <h3>${SecurityManager.sanitizeHTML(result.title)}</h3>
            <p>${SecurityManager.sanitizeHTML(result.description)}</p>
        </div>
    `).join('');

    resultsContainer.innerHTML = html;
}
```

---

## 🛡️ Complete Form Example

### Registration Form with Full Security
```javascript
async function handleRegistration(event) {
    event.preventDefault();

    // 1. VALIDATE ALL INPUTS
    const email = SecurityManager.validateEmail(emailInput.value);
    if (!email) {
        showToast("Error", "Invalid email address", 3000, true);
        return;
    }

    const phone = SecurityManager.validatePhone(phoneInput.value);
    if (!phone) {
        showToast("Error", "Invalid phone number", 3000, true);
        return;
    }

    const name = SecurityManager.validateName(nameInput.value);
    if (!name) {
        showToast("Error", "Invalid name (2-50 characters)", 3000, true);
        return;
    }

    // 2. CHECK RATE LIMIT
    const rateCheck = SecurityManager.checkRateLimit(
        `register_${email}`,
        3, // 3 attempts
        600000 // per 10 minutes
    );

    if (!rateCheck.allowed) {
        showToast("Error", rateCheck.message, 5000, true);
        return;
    }

    // 3. SANITIZE DATA
    const userData = {
        email: SecurityManager.sanitizeHTML(email),
        phone: SecurityManager.sanitizeHTML(phone),
        name: SecurityManager.sanitizeHTML(name)
    };

    try {
        showSpinner(true);

        // 4. CREATE USER
        const userCredential = await createUserWithEmailAndPassword(
            auth,
            userData.email,
            passwordInput.value
        );

        // 5. GENERATE SESSION TOKEN
        await AuthTokenManager.generateToken(userCredential.user.uid);

        // 6. SAVE TO FIRESTORE (with server-side validation via rules)
        await setDoc(doc(db, 'users', userCredential.user.uid), {
            ...userData,
            createdAt: serverTimestamp(),
            role: 'user'
        });

        showToast("Success", "Registration successful!", 3000);

    } catch (error) {
        console.error('Registration error:', error);

        // Log security event
        SecurityManager.logSecurityEvent('registration_failed', {
            email: userData.email,
            error: error.message
        });

        showToast("Error", error.message, 3000, true);
    } finally {
        showSpinner(false);
    }
}
```

---

## 📊 Monitoring Examples

### Log Security Events
```javascript
// Failed login attempt
SecurityManager.logSecurityEvent('login_failed', {
    email: email,
    ip: userIP,
    timestamp: Date.now()
});

// Suspicious activity
SecurityManager.logSecurityEvent('suspicious_activity', {
    userId: currentUser?.uid,
    action: 'multiple_rapid_requests',
    count: attemptCount
});

// Rate limit exceeded
SecurityManager.logSecurityEvent('rate_limit_exceeded', {
    key: rateLimitKey,
    userId: currentUser?.uid
});
```

---

## 🔄 Session Management

### Auto-refresh Token
```javascript
// Refresh token every 12 hours
setInterval(async () => {
    if (currentUser && AuthTokenManager.verifyToken(currentUser.uid)) {
        await AuthTokenManager.refreshToken(currentUser.uid);
        console.log('Session token refreshed');
    }
}, 12 * 60 * 60 * 1000);
```

### Check Token Before Operations
```javascript
async function sensitiveOperation() {
    if (!currentUser) return;

    if (!AuthTokenManager.verifyToken(currentUser.uid)) {
        showToast("Warning", "Session expired. Please re-authenticate.", 3000, false, true);

        // Force re-login
        await signOut(auth);
        window.location.href = '/login';
        return;
    }

    // Proceed...
}
```

---

## ✅ Quick Checklist

Before processing any form:
- [ ] Validate all inputs
- [ ] Check rate limits
- [ ] Verify authentication
- [ ] Verify session token
- [ ] Sanitize HTML
- [ ] Log security events
- [ ] Handle errors gracefully

---

**Remember:** Security is not optional! Always validate, always authenticate, always log.
